﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Guest : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        Label1.Text = "";
        if (!IsPostBack)
        {
            Calendar1.Visible = false;
        }
        if (!IsPostBack)
        {
            Calendar2.Visible = false;
        }
    }

    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
        }
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        fromdate.Text = Calendar1.SelectedDate.ToString("yyyy/MM/dd");
        Calendar1.Visible = false;
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar2.Visible)
        {
            Calendar2.Visible = false;
        }
        else
        {
            Calendar2.Visible = true;
        }
    }

    protected void Calendar2_SelectionChanged(object sender, EventArgs e)
    {
        todate.Text = Calendar2.SelectedDate.ToString("yyyy/MM/dd");
        Calendar2.Visible = false;
    }

    protected void Booking_Click(object sender, EventArgs e)
    {
        //SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        //sqlConnection.Open();
        //string sqlCommandText = $"insert into Client values('{fname.Text}','{email.Text}','{mobile.Text}','{idproof.Text}',{Ge.SelectedItem.Text})";
        //SqlCommand sqlCommand2 = new SqlCommand(sqlCommandText, sqlConnection);
        //sqlCommand2.ExecuteNonQuery();
        //Response.Redirect("ClientLogin.aspx");
        Label1.Text = "Your Hotel is Booked";
    }
}