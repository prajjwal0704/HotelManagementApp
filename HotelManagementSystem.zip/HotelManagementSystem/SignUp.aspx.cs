﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class SignUp : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "";
    }

    protected void signupbutton_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        sqlConnection.Open();
        string mydata = $"select username from Client where username='{ uname.Text}'";
        SqlCommand sqlCommand = new SqlCommand(mydata, sqlConnection);
        var allclient = sqlCommand.ExecuteScalar();
        if (allclient==null)
        {

        string sqlCommandText = $"insert into Client values('{uname.Text}','{password.Text}')";
        SqlCommand sqlCommand2 = new SqlCommand(sqlCommandText, sqlConnection);
        sqlCommand2.ExecuteNonQuery();
        Response.Redirect("ClientLogin.aspx");

        }
        else
        {
            Label1.Text = "Username allready exists";
        }
    }
   
}