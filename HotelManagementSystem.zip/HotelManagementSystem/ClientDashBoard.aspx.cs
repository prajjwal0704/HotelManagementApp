﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;

public partial class ClientDashBoard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "";

        if (!IsPostBack)
        {
            Calendar1.Visible = false;
        }
        if (!IsPostBack)
        {
            Calendar2.Visible = false;
        }
    }

    protected void Booking_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        sqlConnection.Open();
        string textforroom = $"select roomnumber from customer where roomnumber = '{ roomnumber.Text}'";
        SqlCommand room = new SqlCommand(textforroom, sqlConnection);
        var isbooked = room.ExecuteScalar();
        //string textfordate = $"select todate from customer where roomnuber"
        if(isbooked==null)
        {
            string sqlCommandText = $"insert into customer values('{roomnumber.Text}','{Session["username"]}','{Room.SelectedItem.Text}' ,'{fromdate.Text}' ,'{todate.Text}')";
            SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            Label1.Text = "Room Booked";
        }
        else
        {
            Label1.Text = "Room already booked";
        }



        //string sqlCommandText = $"insert into customer values('{roomnumber.Text}','{Session["username"]}','{Room.SelectedItem.Text}' ,'{fromdate.Text}' ,'{todate.Text}')";
        //SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
        //sqlCommand.ExecuteNonQuery();

        //string sqlCommandText2 = ($"delete from EmployeeDetails where roomtype='{Room.SelectedItem.Text}'");
        //SqlCommand sqlCommand2 = new SqlCommand(sqlCommandText, sqlConnection);
        //sqlCommand.ExecuteNonQuery();
    }
    protected void delroom_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        sqlConnection.Open();
        string sqlCommandText2 = ($"delete from customer where roomnumber='{roomnumber.Text}'");
        SqlCommand sqlCommand = new SqlCommand(sqlCommandText2, sqlConnection);
        sqlCommand.ExecuteNonQuery();
        Label1.Text = "Room deleted";
    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar1.Visible)
        {
            Calendar1.Visible = false;
        }
        else
        {
            Calendar1.Visible = true;
        }
    }

    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {
        fromdate.Text = Calendar1.SelectedDate.ToString("yyyy/MM/dd");
        Calendar1.Visible = false;
    }

    protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
    {
        if (Calendar2.Visible)
        {
            Calendar2.Visible = false;
        }
        else
        {
            Calendar2.Visible = true;
        }
    }

    protected void Calendar2_SelectionChanged(object sender, EventArgs e)
    {
        todate.Text = Calendar2.SelectedDate.ToString("yyyy/MM/dd");
        Calendar2.Visible = false;
    }


    protected void pastbooking_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        string sqlCommandText = $"select * from customer where username = '{Session["username"]}'";
        SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
        SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
        DataSet ds = new DataSet();
        adapter.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}