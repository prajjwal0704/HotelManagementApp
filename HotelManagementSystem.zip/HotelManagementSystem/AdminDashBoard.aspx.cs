﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;

public partial class AbminDashBoard : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label1.Text = "";
    }

    protected void addroom_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        sqlConnection.Open();
        string textforroom = $"select roomnumber from room where roomnumber = '{roomnumber.Text}'";
        SqlCommand room = new SqlCommand(textforroom, sqlConnection);
        var isbooked = room.ExecuteScalar();
        //string textfordate = $"select todate from customer where roomnuber"
        if (isbooked == null)
        {
            string sqlCommandText = $"insert into room values('{roomnumber.Text}','{Room.SelectedItem.Text}','{fare.Text}','{capacity.Text}')";
            SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
            sqlCommand.ExecuteNonQuery();
            Label1.Text = "Room Created";
        }
        else
        {
            Label1.Text = "Room already created";
        }
        //SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        //sqlConnection.Open();
        //string sqlCommandText = $"insert into room values('{roomnumber.Text}','{Room.SelectedItem.Text}','{fare.Text}','{capacity.Text}')";
        //SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
        //sqlCommand.ExecuteNonQuery();
    }

    protected void delroom_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        sqlConnection.Open();
        string sqlCommandText2 = ($"delete from room where roomnumber='{roomnumber.Text}'");
        SqlCommand sqlCommand = new SqlCommand(sqlCommandText2, sqlConnection);
        sqlCommand.ExecuteNonQuery();
        Label1.Text = "Room deleted";
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        string sqlCommandText = $"select * from client";
        SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
        SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
        DataSet ds = new DataSet();
        adapter.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }


    protected void room2_Click(object sender, EventArgs e)
    {
        SqlConnection sqlConnection = new SqlConnection(@"server = LAPTOP-HCGJQ0B3\SQLEXPRESS ; database = HotelManagementDb;trusted_connection=yes");
        string sqlCommandText = $"select * from room";
        SqlCommand sqlCommand = new SqlCommand(sqlCommandText, sqlConnection);
        SqlDataAdapter adapter = new SqlDataAdapter(sqlCommand);
        DataSet ds = new DataSet();
        adapter.Fill(ds);
        GridView2.DataSource = ds;
        GridView2.DataBind();
    }
}